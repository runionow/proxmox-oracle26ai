# Draft: Proxmox Oracle 26ai Helper Script

## Requirements (confirmed)
- Create a Proxmox script template for deploying Oracle AI Database 26ai
- Open-source / public project — "help the world" spin up their own Oracle 26ai

## Research Findings

### Oracle AI Database 26ai
- **GA Release**: January 27, 2026 (Linux x86-64)
- **Container image**: `container-registry.oracle.com/database/free:23.26.0.0` (also `:latest`)
- **Two flavors**: Full Image (all features) / Lite Image (~80% smaller, good for CI/CD)
- **Free edition**: No-cost, for dev/learning (resource caps, single instance, no official support)
- **Key ports**: 1521 (listener), 8080 (ORDS if installed)
- **Key env vars**: `ORACLE_PWD` (admin password)
- **Docker run**: `docker run -d --name oracle -e ORACLE_PWD=xxx -p 1521:1521 --shm-size=1g container-registry.oracle.com/database/free:latest`
- **ARM64 support**: Yes (Apple Silicon Macs, ARM servers)

### Proxmox Helper Script Conventions (community-scripts/ProxmoxVE)
- **Structure**: `ct/{app}.sh` (creation), `install/{app}-install.sh` (install), `misc/build.func` (shared)
- **UI**: whiptail-based interactive prompts
- **Pattern**: `pct create` for LXC, `qm create` for VM
- **One-liner install**: `bash <(curl -fsSL https://...)`
- **Conventions**: msg_info/msg_ok/msg_error functions, color output, storage detection

### Deployment Approaches on Proxmox
1. **LXC + Docker/Podman inside** — Lightweight, uses `pct create`, install Docker, pull Oracle image
2. **VM (KVM) + Docker** — Full VM, more isolated, supports `--shm-size`, hugepages
3. **VM (KVM) + native Oracle install** — Heaviest, Oracle Linux base, RPM install

### Existing Related Projects
- `shakiyam/Oracle-AI-Database-26ai-Free-on-Docker` (13 stars) — Simple Docker scripts
- `ggordham/ora-lab` — Terraform + Proxmox for Oracle VMs
- `community-scripts/ProxmoxVE` — Gold standard for Proxmox helper scripts

## Technical Decisions (from interview)
- **Deployment**: BOTH LXC + Docker AND KVM VM + Docker (user chooses at install time)
- **Project format**: Standalone repo (own structure, own README)
- **Container runtime**: Auto-detect / user choice (Docker or Podman)
- **Oracle image**: User chooses Full (~10GB) or Lite (~2GB) at install time
- **Feature approach**: Modular — basic DB first, opt-in scripts for APEX, vector demo, backup, SSL
- **Interactive UI**: whiptail TUI (professional, guided experience)

## Feature Scope (all selected)
1. Basic Oracle 26ai Free DB (port 1521)
2. APEX + ORDS (web UI on port 8080)
3. Vector search demo (sample data + AI feature showcase)
4. Backup/restore scripts
5. SSL/TLS setup (HTTPS for ORDS, encrypted DB connections)

## Target Audience
- Both homelab enthusiasts AND developers
- Need sensible defaults + optional advanced config

## Final Decisions (all resolved)
1. ~~Container runtime~~ → Auto-detect / user choice ✓
2. ~~Oracle image flavor~~ → User chooses (Full/Lite) ✓
3. ~~UI approach~~ → whiptail TUI ✓
4. ~~Modular?~~ → Yes, modular opt-in ✓
5. ~~Networking~~ → DHCP default, static optional via whiptail ✓
6. ~~License~~ → MIT ✓
7. ~~Resources~~ → Defaults: 4 CPU / 8GB RAM / 32GB disk (adjustable via whiptail) ✓

## Test Strategy
- **No unit test framework** — bash scripts project
- **Verification**: Agent-executed QA scenarios (run scripts, verify Oracle connectivity)
- **QA tools**: Bash (curl, sqlplus), tmux for interactive verification

## Scope Boundaries
- INCLUDE: LXC script, VM script, Docker-based Oracle 26ai, APEX/ORDS, vector demo, backup/restore, SSL, README, LICENSE
- EXCLUDE: Native Oracle install (RPM), Terraform, Ansible, CI/CD pipeline, paid Oracle editions, RAC/clustering
